Put Vazirmatn-Regular.ttf and Vazirmatn-Bold.ttf here (free, OFL license:
https://github.com/rastikerdar/vazirmatn). It has Persian AND Latin glyphs, so the
whole UI looks identical on Windows / Android. Without it, SYNORA falls back to a
system font (Segoe UI / Tahoma / Arial / DejaVu).
